# TECH_STACK

## 1. 기본 원칙
1차 무료 공개 베타는 **빠른 출시, 낮은 복잡도, 운영 단순성**을 최우선으로 한다.
따라서 기술 스택은 “필요 최소한”으로 고정한다.

## 2. 운영 환경
- 운영 OS: **Ubuntu Server LTS**
- 개발 환경: **Windows + WSL2 Ubuntu**
- 컨테이너: **Docker / Docker Compose**
- 리버스 프록시: **Caddy** 우선 (대안: Nginx)

선정 이유:
- Linux 기반 배포/운영이 단순함
- Docker Compose로 초기 배포가 쉬움
- Caddy는 HTTPS 자동 구성이 간단함

## 3. 언어 및 런타임
- 주 언어: **Python 3.10**

선정 이유:
- 기존 퀀트 모델과 동일 계열 유지
- 서비스 계층과 모델 계층을 같은 언어로 묶어 단순화
- 초기에는 다중 언어 스택을 피하는 것이 효율적

## 4. 웹 스택
- 웹 프레임워크: **Flask**
- 템플릿 엔진: **Jinja2**
- WSGI 서버: **Gunicorn**
- 정적 파일: Flask 또는 Caddy에서 제공

선정 이유:
- 1차는 읽기 전용 공개 웹이므로 Flask로 충분함
- 템플릿 기반 SSR이 초기 복잡도를 낮춤
- Node 기반 프론트엔드 분리를 1차에서는 하지 않음

## 5. 데이터 저장 전략

### 5.1 1차 추천 데이터
- 형식: **JSON 스냅샷 파일**
- 생성 주기: 일일 배치
- 웹은 JSON만 읽어서 표시

권장 파일:
- `model_catalog.json`
- `daily_recommendations.json`
- `recent_changes.json`
- `performance_summary.json`

### 5.2 1차 피드백 저장
- 우선안: **SQLite**
- 대안: 단순 파일(JSONL/CSV)

선정 이유:
- 사용자 피드백 수집 규모가 작음
- 별도 DB 서버 없이 단순 운영 가능

### 5.3 2차 확장 DB
- 목표 DB: **PostgreSQL**

용도:
- users
- subscriptions
- entitlements
- access_logs
- payment_events

## 6. 테스트 및 품질 도구
- 테스트: **pytest**
- 포맷터: **black**
- 린터: **ruff**
- 선택: mypy(추후)

원칙:
- 최소한의 단위 테스트 또는 검증 스크립트 포함
- 스냅샷 생성 결과는 스키마 검증 포함

## 7. 설정 및 비밀정보 관리
- 환경설정: `.env`
- 로딩 방식: config 모듈에서 `.env` 로드
- 민감정보: Git 커밋 금지

분리 대상:
- 출력 경로
- 웹 포트
- 피드백 저장 경로
- 배치 시간 관련 설정
- 추후 API 키/결제 키

## 8. 배포 방식
- 1차 배포: **Docker Compose 단일 스택**

예상 서비스 구성:
- web
- reverse-proxy
- (선택) scheduler 또는 host cron

원칙:
- Kubernetes 금지
- 마이크로서비스 분리 금지
- 단일 모놀리식 구조 유지

## 9. 보안 기본 원칙
- HTTPS 필수
- 관리자용 원격접속 최소화
- SSH 키 기반 접속
- 비밀값 하드코딩 금지
- 웹 요청 시 모델 실시간 실행 금지

## 10. 1차에서 도입하지 않을 기술
- React / Next.js 등 별도 프론트엔드 프레임워크
- Redis
- Kafka / 메시지 큐
- Kubernetes
- 별도 관리형 DB
- 실시간 WebSocket
- 모바일 앱

## 11. 2차 확장 고려 사항
1차 스택은 아래 확장을 수용할 수 있어야 한다.
- PostgreSQL 연결
- 회원/권한 미들웨어 추가
- 결제 웹훅 추가
- 무료/유료 노출 분기
- 이메일/알림 모듈 추가

## 12. 최종 스택 요약
- Python 3.10
- Flask + Jinja2
- Gunicorn
- Caddy
- Docker Compose
- JSON 스냅샷
- SQLite(피드백)
- pytest / black / ruff
- 2차 확장 시 PostgreSQL
