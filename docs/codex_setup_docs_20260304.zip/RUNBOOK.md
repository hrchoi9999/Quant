# RUNBOOK

## 1. 목적
본 문서는 1차 무료 공개 베타 기준의 기본 실행·검증 절차를 정의한다.
실제 명령은 구현 상태에 따라 조정할 수 있으나, Codex는 이 실행 흐름을 기준으로 작업한다.

## 2. 개발 환경 준비

### 2.1 기본 환경
- Python 3.10
- 가상환경 사용 권장
- Docker / Docker Compose 설치
- WSL2 Ubuntu 또는 Linux 환경 권장

### 2.2 가상환경 예시
```bash
python3.10 -m venv .venv
source .venv/bin/activate
```

### 2.3 의존성 설치 예시
```bash
pip install -r requirements.txt
```

## 3. 환경설정
프로젝트 루트 또는 지정 경로에 `.env` 파일을 둔다.

예시 항목:
```env
APP_ENV=development
WEB_HOST=0.0.0.0
WEB_PORT=8000
PUBLIC_DATA_DIR=./service_platform/web/public_data
FEEDBACK_DB_PATH=./data/feedback.db
LOG_LEVEL=INFO
```

원칙:
- 민감정보는 `.env` 사용
- 경로/포트 하드코딩 금지

## 4. 코드 품질 점검
### 4.1 포맷팅
```bash
black .
```

### 4.2 린트
```bash
ruff check .
```

## 5. 테스트 실행
### 5.1 전체 테스트
```bash
pytest -q
```

### 5.2 특정 영역 테스트 예시
```bash
pytest tests/test_publishers -q
pytest tests/test_feedback -q
pytest tests/test_web -q
```

원칙:
- 신규 기능 추가 시 최소 검증 실행 포함

## 6. 스냅샷 발행 배치 실행
### 6.1 일일 발행 실행 예시
```bash
python -m service_platform.publishers.run_daily_publish
```
또는
```bash
python service_platform/publishers/run_daily_publish.py
```

### 6.2 기대 결과
실행 후 아래 파일이 생성되어야 한다.
- `model_catalog.json`
- `daily_recommendations.json`
- `recent_changes.json`
- `performance_summary.json`

### 6.3 검증 항목
- JSON 파일 생성 여부
- 스키마 검증 통과 여부
- 로그 출력 여부
- 실패 시 에러 메시지 명확성

## 7. 웹 서버 실행
### 7.1 개발 실행 예시
```bash
python -m service_platform.web.app
```
또는
```bash
flask --app service_platform.web.app run --host 0.0.0.0 --port 8000
```

### 7.2 운영 실행 예시
```bash
gunicorn -w 2 -b 0.0.0.0:8000 service_platform.web.app:app
```

### 7.3 확인 항목
- 홈 페이지 응답
- 오늘의 추천 표시
- 모델 설명 표시
- 최근 변화 표시
- 피드백 페이지 동작

## 8. 피드백 기능 검증
검증 항목:
- 이메일 형식 최소 검증
- 입력 저장 성공 여부
- 저장 실패 시 사용자 메시지 처리
- 운영자가 저장 결과를 확인 가능한지

## 9. Docker Compose 실행 기준
### 9.1 빌드 및 실행 예시
```bash
docker compose up --build
```

### 9.2 기대 결과
- reverse proxy 기동
- web 서비스 기동
- 정적/공개 데이터 접근 가능

## 10. 배치 운영 기준
1차 운영에서는 아래 중 하나를 사용한다.
- host cron
- 간단한 스케줄러
- 수동 실행(초기 검증 시)

원칙:
- 웹 요청에서 배치를 호출하지 않는다.
- 배치는 독립 실행 구조여야 한다.

## 11. 장애 시 확인 순서
### 11.1 추천 데이터가 안 보일 때
1. 배치 실행 로그 확인
2. JSON 스냅샷 생성 여부 확인
3. 스키마 검증 실패 여부 확인
4. `PUBLIC_DATA_DIR` 경로 확인
5. 웹 템플릿 로딩 오류 확인

### 11.2 피드백 저장이 안 될 때
1. 저장 경로/DB 경로 확인
2. 쓰기 권한 확인
3. 입력 검증 실패 여부 확인
4. 예외 로그 확인

### 11.3 웹이 안 뜰 때
1. 포트 충돌 확인
2. Flask/Gunicorn 실행 로그 확인
3. reverse proxy 설정 확인
4. `.env` 로딩 여부 확인

## 12. 운영 점검 체크리스트
- 최신 스냅샷 생성 완료
- 기준일(as_of_date) 정상 반영
- 홈/추천/모델/변화 페이지 정상 표시
- 피드백 저장 정상
- 로그 파일 비정상 증가 여부 없음
- 포트/도메인 접근 정상

## 13. 2차 확장 시 추가될 실행 항목
2차 유료화 전환 시 아래 항목이 추가될 수 있다.
- DB 마이그레이션
- 사용자 인증 초기화
- 결제 웹훅 서버 검증
- 권한 분기 테스트

단, 본 문서는 1차 무료 공개 베타를 기준으로 한다.
