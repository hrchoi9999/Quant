# TASK 01 — 서비스 표준 스키마 정의

## 목적
기존 퀀트 모델의 산출 결과를 웹서비스에서 공통으로 사용할 수 있도록 **서비스 표준 데이터 스키마**를 먼저 고정한다.

이 작업은 1차 무료 공개 베타의 첫 번째 구현 작업이다. 이후 adapter, daily publish 배치, 웹 UI는 이 스키마를 기준으로 구현한다.

## 선행 기준 문서
Codex는 아래 문서를 먼저 읽고 이 작업을 수행한다.

- `CODEX_COMMON_GUIDE_20260304.md`
- `PROJECT_BRIEF.md`
- `TECH_STACK.md`
- `ARCHITECTURE.md`
- `CONVENTIONS.md`
- `RUNBOOK.md`
- `PROTECTED_AREAS.md`

## 핵심 원칙
1. `quant_models/` 내부 계산 로직은 수정하지 않는다.
2. 이 작업은 **서비스 계층의 표준 형식 정의**만 담당한다.
3. 1차 무료 베타는 **JSON 스냅샷 기반**으로 동작한다.
4. DB 중심 설계는 하지 않고, 향후 PostgreSQL 확장을 고려한 필드 구조만 유지한다.
5. 스키마는 사람이 읽기 쉬워야 하고, 웹 표시와 adapter 구현에 바로 사용할 수 있어야 한다.

## 구현 범위
다음 4개 JSON 스키마와 샘플 파일을 정의한다.

### 1) 모델 카탈로그
- 파일명: `model_catalog.json`
- 목적: 활성 모델 목록, 모델 설명, 리스크 고지

### 2) 일일 추천 스냅샷
- 파일명: `daily_recommendations.json`
- 목적: 모델별 상위 추천 종목과 기준일 정보

### 3) 최근 변화 스냅샷
- 파일명: `recent_changes.json`
- 목적: 신규 편입/편출/순위 변화 등 이벤트 요약

### 4) 성과 요약 스냅샷
- 파일명: `performance_summary.json`
- 목적: 백테스트 핵심 성과지표의 요약 표시

또한 아래를 포함한다.

- 각 스키마에 대응하는 샘플 JSON 생성
- 스키마 검증 유틸 작성
- 최소 테스트 또는 검증 스크립트 작성

## 생성/수정 대상 디렉터리
- `service_platform/schemas/`
- `service_platform/publishers/writers/validate_schema.py`
- `tests/test_publishers/`

## 권장 파일 구성
- `service_platform/schemas/model_catalog.schema.json`
- `service_platform/schemas/daily_recommendations.schema.json`
- `service_platform/schemas/recent_changes.schema.json`
- `service_platform/schemas/performance_summary.schema.json`
- `service_platform/schemas/examples/model_catalog.example.json`
- `service_platform/schemas/examples/daily_recommendations.example.json`
- `service_platform/schemas/examples/recent_changes.example.json`
- `service_platform/schemas/examples/performance_summary.example.json`
- `service_platform/publishers/writers/validate_schema.py`
- `tests/test_publishers/test_schema_validation.py`

## 필수 필드 정의

### A. `model_catalog.json`
최소 필드:
- `models[]`
  - `model_id` (string)
  - `model_name` (string)
  - `summary` (string)
  - `style` (string)
  - `risk_note` (string)
  - `is_active` (boolean)

### B. `daily_recommendations.json`
최소 필드:
- `as_of_date` (YYYY-MM-DD)
- `generated_at` (ISO datetime)
- `models[]`
  - `model_id` (string)
  - `top_picks[]`
    - `rank` (integer)
    - `ticker` (string)
    - `stock_name` (string)
    - `score` (number)
    - `reason_summary` (string)
    - `change_type` (enum: `new`, `maintain`, `up`, `down`, `exit_pending`)
- `disclaimer` (string)

### C. `recent_changes.json`
최소 필드:
- `as_of_date` (YYYY-MM-DD)
- `changes[]`
  - `model_id` (string)
  - `ticker` (string)
  - `stock_name` (string)
  - `event` (enum: `new_entry`, `exit`, `rank_up`, `rank_down`)
  - `summary` (string)

### D. `performance_summary.json`
최소 필드:
- `models[]`
  - `model_id` (string)
  - `cagr` (number)
  - `mdd` (number)
  - `sharpe` (number)
  - `note` (string)

## 구현 제약
- `quant_models/` 내 기존 파일 수정 금지
- Flask 웹 코드 작성 금지 (이번 작업 범위 아님)
- adapter 구현 금지 (이번 작업 범위 아님)
- 배치 실행 스크립트 구현 금지 (이번 작업 범위 아님)
- 회원/결제/권한 관련 구조 추가 금지

## 구현 상세 지침
1. JSON Schema Draft 규격을 사용하되, 과도하게 복잡하게 만들지 말 것.
2. 날짜/시간 형식은 검증 가능하게 둘 것.
3. enum 필드는 향후 adapter에서 그대로 쓰기 쉽게 고정할 것.
4. 스키마는 선택 필드보다 필수 필드를 우선 명확히 정의할 것.
5. 샘플 JSON은 실제 서비스 화면에 바로 투입 가능한 수준으로 작성할 것.
6. `README` 또는 주석으로 각 파일의 역할을 짧게 설명할 것.

## 완료 기준 (Definition of Done)
다음 조건을 모두 충족해야 완료로 본다.

1. 스키마 파일 4종 생성 완료
2. 샘플 JSON 파일 4종 생성 완료
3. 샘플 JSON이 각 스키마 검증을 통과
4. 검증 유틸이 CLI 또는 함수 형태로 실행 가능
5. 테스트 또는 검증 스크립트 포함
6. 변경 파일 목록과 각 파일의 역할 요약 포함

## Codex 응답 형식 요구
작업 완료 후 아래 형식으로 요약한다.

1. 생성/수정한 파일 목록
2. 각 파일의 역할 요약
3. 스키마 검증 실행 방법
4. 남은 후속 작업(다음 단계: adapter 구현)

## 다음 작업과의 연결
이 작업이 끝나면 바로 다음 작업은 아래다.

- `TASK 02 — 기존 퀀트 모델 어댑터 구현`

즉, 이번 작업의 산출물은 이후 adapter가 따를 **절대 기준 형식**이어야 한다.
